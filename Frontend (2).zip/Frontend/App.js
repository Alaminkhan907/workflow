import "./global.css";
import React from "react";
import AppNavigator from "./app/navigation/AppNavigator";
import Test from "./app/navigation/test"

export default function App() {
  // return <AppNavigator />;
  return <Test />;
}
