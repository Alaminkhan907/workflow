// Backend-server/tests/trial.test.js
describe('Sanity Check', () => {
    test('Should always succeed', () => {
      console.log('The test environment is set up and running correctly.');
      expect(true).toBe(true); // always passes for testing
    });
  });